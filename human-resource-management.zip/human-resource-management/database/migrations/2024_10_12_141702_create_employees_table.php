<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateEmployeesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('employees', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->nullable()->constrained('users');
            $table->string('name', 255)->nullable();
            $table->string('username', 255)->nullable();
            $table->string('phone', 18)->nullable();
            $table->string('email', 100)->nullable();
            $table->date('datebirth')->nullable();
            $table->string('country')->nullable();
            $table->string('gender')->nullable();
            $table->string('image')->nullable();
            $table->tinyInteger('status')->default(1);
            $table->unsignedBigInteger('employment_type_id')->nullable()->constrained('employment_types')->onDelete('cascade');
            $table->unsignedBigInteger('department_id')->nullable()->constrained('departments')->onDelete('cascade');;
            $table->unsignedBigInteger('designation_id')->nullable()->constrained('designations')->onDelete('cascade');;
            $table->integer('total_leave')->nullable();
            $table->date('start_working_day')->nullable();
            $table->decimal('salary', 15, 2)->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('employees');
    }
}

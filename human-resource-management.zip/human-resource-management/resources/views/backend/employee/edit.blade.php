@php
    $today = \Carbon\Carbon::today()->format('Y-m-d');
@endphp

@extends('layouts.admin')

@section('content')
    @if (Session::has('success'))
        <script>
            swal({
                title: "Success",
                text: "The operation completed successfully!",
                icon: "success",
                timer: 3000
            });
        </script>
    @endif

    @if (Session::has('error'))
        <script>
            swal({
                title: "Error!",
                text: "There was an error!",
                icon: "error"
            });
        </script>
    @endif

    <div class="row container">
        <div class="col-md-12 container">
            <form method="POST" action="{{ route('employee.update', $employee->id) }}" enctype="multipart/form-data">
                @csrf
                @method('PUT')
                <div class="card">
                    <div class="card-header bg-secondary card_header">
                        <div class="row">
                            <div class="col-md-8 card_header_title">
                                <i class="md md-add-circle"></i> USER REGISTRATION EDIT NOW
                            </div>
                            <div class="col-md-4 card_header_btn">
                                <a href="{{ route('alluser') }}" class="btn btn-xs btn-dark"
                                    style="float: right; color:white;">
                                    <i class="md md-view-module"></i> All User
                                </a>
                            </div>
                        </div>
                    </div>

                    <div class="card-body">

                        <!-- Name Field -->
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label col_form_label">Name<span
                                    class="req_star">*</span>:</label>
                            <div class="col-sm-7">
                                <input type="text" class="form-control form_control" placeholder="Enter Your Name"
                                    name="name" value="{{ old('name', $employee->name) }}">
                                @error('name')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <!-- Username Field -->
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label col_form_label">Username<span
                                    class="req_star">*</span>:</label>
                            <div class="col-sm-7">
                                <input type="text" class="form-control form_control" placeholder="Enter Username"
                                    name="username" value="{{ old('username', $employee->username) }}">
                                @error('username')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <!-- Phone Field -->
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label col_form_label">Phone:</label>
                            <div class="col-sm-7">
                                <input type="text" class="form-control form_control" placeholder="Enter Phone Number"
                                    name="phone" value="{{ old('phone', $employee->phone) }}">
                                @error('phone')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <!-- Email Field -->
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label col_form_label">Email<span
                                    class="req_star">*</span>:</label>
                            <div class="col-sm-7">
                                <input type="email" class="form-control form_control" placeholder="Enter Email"
                                    name="email" value="{{ old('email', $employee->email) }}">
                                @error('email')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <!-- Date of Birth Field -->
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label col_form_label">Date of Birth<span
                                    class="req_star">*</span>:</label>
                            <div class="col-sm-7">
                                <input type="date" class="form-control form_control" name="datebirth"
                                    value="{{ old('datebirth', $employee->datebirth) }}">
                                @error('datebirth')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <!-- Country Field -->
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label col_form_label">Country<span
                                    class="req_star">*</span>:</label>
                            <div class="col-sm-7">
                                <select class="form-control form_control" name="country">
                                    <option value="">Choose Country</option>
                                    <option value="Bangladesh"
                                        {{ old('country', $employee->country) == 'Bangladesh' ? 'selected' : '' }}>
                                        Bangladesh</option>
                                    <option value="India"
                                        {{ old('country', $employee->country) == 'India' ? 'selected' : '' }}>India
                                    </option>
                                    <option value="Japan"
                                        {{ old('country', $employee->country) == 'Japan' ? 'selected' : '' }}>Japan
                                    </option>
                                </select>
                                @error('country')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <!-- Gender Field -->
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label col_form_label">Gender<span
                                    class="req_star">*</span>:</label>
                            <div class="col-sm-7">
                                <select class="form-control form_control" name="gender">
                                    <option value="">Choose Gender</option>
                                    <option value="Male"
                                        {{ old('gender', $employee->gender) == 'Male' ? 'selected' : '' }}>Male</option>
                                    <option value="Female"
                                        {{ old('gender', $employee->gender) == 'Female' ? 'selected' : '' }}>Female
                                    </option>
                                </select>
                                @error('gender')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <!-- Employment Type Field -->
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label col_form_label">Employment Type<span
                                    class="req_star">*</span>:</label>
                            <div class="col-sm-7">
                                <select class="form-control form_control" name="employment_type_id">
                                    <option value="">Choose Employment Type</option>
                                    @foreach ($employmentTypes as $type)
                                        <option value="{{ $type->id }}"
                                            {{ old('employment_type_id', $employee->employment_type_id) == $type->id ? 'selected' : '' }}>
                                            {{ $type->name }}</option>
                                    @endforeach
                                </select>
                                @error('employment_type_id')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <!-- Department Field -->
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label col_form_label">Department<span
                                    class="req_star">*</span>:</label>
                            <div class="col-sm-7">
                                <select class="form-control form_control" name="department_id">
                                    <option value="">Choose Department</option>
                                    @foreach ($departments as $department)
                                        <option value="{{ $department->id }}"
                                            {{ old('department_id', $employee->department_id) == $department->id ? 'selected' : '' }}>
                                            {{ $department->name }}</option>
                                    @endforeach
                                </select>
                                @error('department_id')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <!-- Designation Field -->
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label col_form_label">Designation<span
                                    class="req_star">*</span>:</label>
                            <div class="col-sm-7">
                                <select class="form-control form_control" name="designation_id">
                                    <option value="">Choose Designation</option>
                                    @foreach ($designations as $designation)
                                        <option value="{{ $designation->id }}"
                                            {{ old('designation_id', $employee->designation_id) == $designation->id ? 'selected' : '' }}>
                                            {{ $designation->name }}</option>
                                    @endforeach
                                </select>
                                @error('designation_id')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <!-- Total Leave Field -->
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label col_form_label">Total Leave:</label>
                            <div class="col-sm-7">
                                <input type="number" class="form-control form_control"
                                    placeholder="Enter Total Leave Number" name="total_leave"
                                    value="{{ old('total_leave', $employee->total_leave) }}">
                                @error('total_leave')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <!-- Start Working Day Field -->
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label col_form_label">Start Working Date<span
                                    class="req_star">*</span>:</label>
                            <div class="col-sm-7">
                                <input type="date" class="form-control form_control" name="start_working_day"
                                    value="{{ old('start_working_day', $employee->start_working_day) }}">
                                @error('start_working_day')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <!-- Salary Field -->
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label col_form_label">Salary:</label>
                            <div class="col-sm-7">
                                <input type="number" class="form-control form_control" placeholder="Enter Salary"
                                    name="salary" value="{{ old('salary', $employee->salary) }}">
                                @error('salary')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <!-- Image Field -->
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label col_form_label">Profile Image:</label>
                            <div class="col-sm-7">
                                <input type="file" class="form-control form_control" name="image">
                                @error('image')
                                    <span class="text-danger">{{ $message }}</span>
                                @enderror
                                <img src="{{ asset('upload/employee/' . $employee->image) }}" alt="Profile Image"
                                    style="width: 100px; margin-top: 10px;">
                            </div>
                        </div>

                    </div>

                    <div class="card-footer bg-secondary card_footer">
                        <button type="submit" class="btn btn-dark">UPDATE</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
@endsection

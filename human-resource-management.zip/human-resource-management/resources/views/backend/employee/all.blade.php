@extends('layouts.admin')

@section('content')
    @if (Session::has('success'))
        <script>
            swal({
                title: "Good job!",
                text: "The operation completed successfully!",
                icon: "success",
                timer: 3000,
            });
        </script>
    @endif

    @if (Session::has('error'))
        <script>
            swal({
                title: "Error!",
                text: "Something went wrong!",
                icon: "error",
            });
        </script>
    @endif

    <br>
    <div class="row container">
        <div class="col-md-12 container">
            <div class="card">
                <div class="card-header bg-secondary card_header">
                    <div class="row">
                        <div class="col-md-8 card_header_title">
                            <i class="md md-add-circle "></i> All Employee Information
                        </div>
                        <div class="col-md-4 card_header_btn">
                            <a href="{{ route('employee.create') }}" class="btn btn-xs btn-dark" style="float: right; color:white;">
                                <i class="md md-view-module"></i> Add Employee
                            </a>
                        </div>
                    </div>
                </div>
                <br>
                <div class="tab-content">
                    <div class="tab-pane show active" id="basic-datatable-preview">
                        <div id="basic-datatable_wrapper" class="dataTables_wrapper dt-bootstrap5 no-footer">
                            <div class="row">
                                <div class="col-sm-12">
                                    <table class="table table-bordered dt-responsive nowrap w-100">
                                        <thead>
                                            <tr>
                                                <th>Name</th>
                                                <th>Phone</th>
                                                <th>Email</th>
                                                <th>Username</th>
                                                <th>Photo</th>
                                                <th>Manage</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach ($employees as $employee)
                                                <tr>
                                                    <td>{{ $employee->name }}</td>
                                                    <td>{{ $employee->phone }}</td>
                                                    <td>{{ $employee->email }}</td>
                                                    <td>{{ $employee->username }}</td>
                                                    <td>
                                                        @if (!empty($employee->image))
                                                            <img class="img-fluid img" src="{{ asset('upload/employee/' . $employee->image) }}" style="width: 50px;">
                                                        @else
                                                            <img class="img-fluid img" src="{{ asset('upload/avater.jpg') }}" style="width: 50px;">
                                                        @endif
                                                    </td>
                                                    <td>
                                                        <div class="btn-group mb-2">
                                                            <div class="btn-group">
                                                                <button type="button" class="btn btn-dark dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                                                                    Manage <span class="caret"></span>
                                                                </button>
                                                                <div class="dropdown-menu">
                                                                    <a class="dropdown-item" href="{{ route('employee.edit', $employee->id) }}">Edit</a>
                                                                    <a class="dropdown-item" href="{{ route('employee.show', $employee->id) }}">View</a>
                                                                    <a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#delete-modal-{{ $employee->id }}">Delete</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>

                                                <!-- Delete Modal -->
                                                <div id="delete-modal-{{ $employee->id }}" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="delete-modalLabel-{{ $employee->id }}" aria-hidden="true">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <div class="modal-header modal-colored-header bg-danger">
                                                                <h4 class="modal-title" id="delete-modalLabel">Warning</h4>
                                                            </div>
                                                            <div class="modal-body">
                                                                <p>Are you sure you want to delete <b>{{ $employee->name }}</b>?</p>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-light" data-bs-dismiss="modal">No</button>
                                                                <form id="delete-form"
                                                                    action="{{ route('employee.destroy', $employee->id) }}"
                                                                    method="POST" style="display: none;">
                                                                    @csrf
                                                                    @method('DELETE')
                                                                    <button type="submit" class="btn btn-dark">Yes</button>
                                                                </form>
                                                                {{-- <a href="{{ route('employee.destroy', $employee->id) }}" class="btn btn-dark">Yes</a> --}}
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- End Modal -->
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card-footer bg-secondary card_footer">
                    <div class="btn-group" role="group">
                        <a type="button" class="btn btn-xs btn-dark">Print</a>
                        <a type="button" class="btn btn-xs btn-warning">Excel</a>
                        <a type="button" class="btn btn-xs btn-dark">PDF</a>
                    </div>
                </div>

            </div>
        </div>
    </div>
@endsection

@section('custom_css')
    <!-- DataTables -->
    <link href="{{ asset('backend') }}/assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" />
    <link href="{{ asset('backend') }}/assets/libs/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css" rel="stylesheet" type="text/css" />
    <!-- Responsive datatable examples -->
    <link href="{{ asset('backend') }}/assets/libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css" rel="stylesheet" type="text/css" />
@endsection

@section('custom_js')
    <!-- Required datatable js -->
    <script src="{{ asset('backend') }}/assets/libs/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="{{ asset('backend') }}/assets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
    <!-- Buttons examples -->
    <script src="{{ asset('backend') }}/assets/libs/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="{{ asset('backend') }}/assets/libs/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js"></script>
    <script src="{{ asset('backend') }}/assets/libs/jszip/jszip.min.js"></script>
    <script src="{{ asset('backend') }}/assets/libs/pdfmake/build/pdfmake.min.js"></script>
    <script src="{{ asset('backend') }}/assets/libs/pdfmake/build/vfs_fonts.js"></script>
    <script src="{{ asset('backend') }}/assets/libs/datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="{{ asset('backend') }}/assets/libs/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="{{ asset('backend') }}/assets/libs/datatables.net-buttons/js/buttons.colVis.min.js"></script>

    <!-- Responsive examples -->
    <script src="{{ asset('backend') }}/assets/libs/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
    <script src="{{ asset('backend') }}/assets/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js"></script>

    <!-- Datatable init js -->
    <script src="{{ asset('backend') }}/assets/js/pages/datatables.init.js"></script>
@endsection

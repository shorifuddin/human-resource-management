<?php

namespace App\Http\Controllers\Admin;

use App\Models\Employee;
use App\Models\Department;
use App\Models\LeaveBalance;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;

class AdminController extends Controller
{
    public function __construct(){
        $this->middleware('auth');
    }

    public function index(){
        $employee = Auth::user()->employee;

        $totalEmployees = Employee::count();
        $totalDepartments = Department::count();
        $totalLeaveAvailable = $employee
        ? LeaveBalance::where('employee_id', $employee->id)->sum('remaining_day')
        : 14;

        $employmentType = $employee ? $employee = Auth::user()->employee->employmentType->name : 'Full Time';
        $department = $employee ? $employee = Auth::user()->employee->department->name : 'Developer';
        
        return view('backend.admin.index', compact('totalEmployees', 'totalDepartments', 'totalLeaveAvailable', 'employmentType', 'department'));
    }

    public function recycle(){
        return view('backend.admin.recycle');
    }

    public function logout () {
        auth()->logout();
        return redirect('/');
    }
}

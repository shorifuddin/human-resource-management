<?php

namespace App\Http\Controllers;

use App\Models\LeaveBalance;
use App\Models\LeaveType;
use App\Models\LeaveRequest;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Session;

class LeaveRequestController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $alldata = LeaveRequest::all();
        return view('backend.leaveRequest.all', compact('alldata'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $leaveTypes = LeaveType::all();
        return view('backend.leaveRequest.add', compact('leaveTypes'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'leave_type_id' => 'required|exists:leave_types,id',
            'start_date' => 'required|date',
            'end_date' => 'required|date|after_or_equal:start_date',
            'request_day' => 'required|integer|min:1',
        ]);

        $insert = LeaveRequest::create([
            'employee_id' => auth()->id(),
            'leave_type_id' => $request->leave_type_id,
            'start_date' => $request->start_date,
            'end_date' => $request->end_date,
            'request_day' => $request->request_day,
            'status' => 1,
            'created_by' => auth()->id(), 
        ]);

        if ($insert) {
            Session::flash('success', 'Leave request submitted successfully');
            return redirect()->route('leave-request.index');
        }

        Session::flash('error', 'Failed to submit the leave request');
        return redirect()->back();
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\LeaveRequest  $leaveRequest
     * @return \Illuminate\Http\Response
     */
    public function show(LeaveRequest $leaveRequest)
    {
        return view('backend.leaveRequest.view', compact('leaveRequest'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\LeaveRequest  $leaveRequest
     * @return \Illuminate\Http\Response
     */
    public function edit(LeaveRequest $leaveRequest)
    {
        return view('backend.leaveRequest.edit', compact('leaveRequest'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\LeaveRequest  $leaveRequest
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, LeaveRequest $leaveRequest)
    {
        $leaveRequest->name = $request->name;
        $leaveRequest->update();

        if ($leaveRequest->update()) {
            Session::flash('success', 'Value');
            return redirect()->route('leave-request.index');
        }
        Session::flash('error', 'Value');
        return redirect()->back();
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\LeaveRequest  $leaveRequest
     * @return \Illuminate\Http\Response
     */
    public function updateStatus(Request $request, $id, $status)
    {
        // Find the leave request
        $leaveRequest = LeaveRequest::findOrFail($id);

        // Check if status is '3' (assuming '3' means "approved")
        if ($status == 3) {
            // Get or create the employee's leave balance
            $leaveBalance = LeaveBalance::firstOrCreate(
                ['employee_id' => $leaveRequest->employee_id],
                [
                    'remaining_day' => 14, // Default remaining days
                    'total_day' => 14,     // Default total leave days per year
                    'created_by' => auth()->id(),
                ]
            );

            // Calculate how many days the employee is requesting for this leave
            $requestedDays = $leaveRequest->request_day;

            // Check if remaining leave days are sufficient for the request
            if ($leaveBalance->remaining_day < $requestedDays) {
                // If not enough remaining days, automatically reject the request
                Session::flash('error', 'Leave request exceeds remaining leave balance. Request rejected.');
                $leaveRequest->status = 0; // Assume '0' is rejected status
                $leaveRequest->save();
                return redirect()->route('leave-request.index');
            }

            // Deduct the requested days from remaining days
            $leaveBalance->remaining_day -= $requestedDays;
            $leaveBalance->updated_by = auth()->id(); // Set the user who updated the balance
            $leaveBalance->save(); // Save the updated balance
        }

        // Update the leave request status
        $leaveRequest->status = $status;
        if ($leaveRequest->save()) {
            Session::flash('success', 'Leave request status updated successfully');
        } else {
            Session::flash('error', 'Failed to update leave request status');
        }

        return redirect()->route('leave-request.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\LeaveRequest  $leaveRequest
     * @return \Illuminate\Http\Response
     */
    public function destroy(LeaveRequest $leaveRequest)
    {
        $leaveRequest->delete();
        return redirect()->route('leave-request.index');
    }
}

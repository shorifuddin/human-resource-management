<?php

namespace App\Http\Controllers;

use Carbon\Carbon;
use App\Models\Attendance;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Staff;
use App\Models\User;
use Illuminate\Support\Facades\Auth;

class AttendanceController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // Get today's date
        $today = Carbon::today();

        // Retrieve all employees
        $employees = User::all(); // Assuming you have an Employee model

        // Retrieve today's attendance records for employees
        $attendances = Attendance::whereDate('check_in_date_time', $today)
            ->orWhereDate('check_out_date_time', $today)
            ->get()
            ->keyBy('employee_id'); // Key by employee_id for easier access later

        // Create an array to store the attendance status
        $attendanceStatus = [];

        foreach ($employees as $employee) {
            $attendanceStatus[] = [
                'employee' => $employee,
                'check_in_time' => $attendances->has($employee->id) ? $attendances->get($employee->id)->check_in_date_time : null,
                'check_out_time' => $attendances->has($employee->id) ? $attendances->get($employee->id)->check_out_date_time : null,
            ];
        }

        return view('backend.attendance.all', compact('attendanceStatus', 'today'));
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // Check if the employee has already checked in today
        $existingAttendance = Attendance::where('employee_id', Auth::id())
            ->whereDate('check_in_date_time', Carbon::today())
            ->first();

        if ($existingAttendance) {
            return redirect()->back()->with('error', 'You have already checked in today.');
        }

        // Create a new attendance record with the check-in time
        Attendance::create([
            'employee_id' => Auth::id(),
            'check_in_date_time' => Carbon::now(), // Current date and time for check-in
        ]);

        return redirect()->back()->with('success', 'Check-in successful!');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Attendance  $attendance
     * @return \Illuminate\Http\Response
     */
    public function show(Attendance $attendance)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Attendance  $attendance
     * @return \Illuminate\Http\Response
     */
    public function edit(Attendance $attendance)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Attendance  $attendance
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        // Find the attendance record for the employee that has checked in today
        $attendance = Attendance::where('employee_id', Auth::id())
            ->where('id', $id)
            ->whereDate('check_in_date_time', Carbon::today())
            ->first();

        if (!$attendance) {
            return redirect()->back()->with('error', 'No check-in record found for today.');
        }

        // Ensure the user hasn't already checked out
        if ($attendance->check_out_date_time) {
            return redirect()->back()->with('error', 'You have already checked out today.');
        }

        // Update the record with the check-out time
        $attendance->update([
            'check_out_date_time' => Carbon::now(), // Current date and time for check-out
        ]);

        return redirect()->back()->with('success', 'Check-out successful!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Attendance  $attendance
     * @return \Illuminate\Http\Response
     */
    public function destroy(Attendance $attendance)
    {
        //
    }
}

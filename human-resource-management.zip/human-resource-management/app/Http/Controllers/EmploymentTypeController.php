<?php

namespace App\Http\Controllers;

use App\Models\EmploymentType;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class EmploymentTypeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $alldata = EmploymentType::all();
        return view('backend.employmentType.all', compact('alldata'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('backend.employmentType.add');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $insert = EmploymentType::create([
            'name' => $request->name,
            'short_name' => $request->short_name,
            'created_by' => auth()->id(),
        ]);

        if ($insert) {
            Session::flash('success', 'Value');
            return redirect()->route('employment-type.index');
        }
        Session::flash('error', 'Value');
        return redirect()->back();
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\EmploymentType  $employmentType
     * @return \Illuminate\Http\Response
     */
    public function show(EmploymentType $employmentType)
    {
        return view('backend.employmentType.view', compact('employmentType'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\EmploymentType  $employmentType
     * @return \Illuminate\Http\Response
     */
    public function edit(EmploymentType $employmentType)
    {
        return view('backend.employmentType.edit', compact('employmentType'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\EmploymentType  $employmentType
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, EmploymentType $employmentType)
    {
        $employmentType->name = $request->name;
        $employmentType->short_name = $request->short_name;
        $employmentType->update();

        if ($employmentType->update()) {
            Session::flash('success', 'Value');
            return redirect()->route('employment-type.index');
        }
        Session::flash('error', 'Value');
        return redirect()->back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\EmploymentType  $employmentType
     * @return \Illuminate\Http\Response
     */
    public function destroy(EmploymentType $employmentType)
    {
        $employmentType->delete();
        return redirect()->route('employment-type.index');
    }
}

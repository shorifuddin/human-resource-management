<?php

namespace App\Http\Controllers;

use App\Models\Employee;
use App\Models\Department;
use App\Models\Designation;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use App\Models\EmploymentType;
use App\Http\Controllers\Controller;
use Intervention\Image\Facades\Image;
use Illuminate\Support\Facades\Session;
use App\Http\Controllers\Auth\RegisteredUserController;

class EmployeeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $employees = Employee::where('status', 1)->get();

        // Pass data to the view
        return view('backend.employee.all', compact('employees'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $employmentTypes = EmploymentType::all();
        $departments = Department::all();
        $designations = Designation::all();

        return view('backend.employee.add', compact('employmentTypes', 'departments', 'designations'));
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'username' => 'required|string|max:255|unique:employees,username',
            'phone' => 'nullable|numeric',
            'email' => 'required|email|max:100|unique:employees,email',
            'datebirth' => 'required|date',
            'country' => 'required',
            'gender' => 'required',
            'employment_type_id' => 'required|exists:employment_types,id',
            'department_id' => 'required|exists:departments,id',
            'designation_id' => 'required|exists:designations,id',
            'total_leave' => 'required',
            'start_working_day' => 'required|date',
            'salary' => 'required',
            'image' => 'nullable|image',
        ]);

        // Handle image upload
        $image_name = '';
        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $image_name = time() . '_' . rand(100000, 10000000) . '.' . $image->getClientOriginalExtension();
            Image::make($image)->resize(720, 720)->save('upload/employee/' . $image_name);
        }

        // Insert employee without user_id initially
        $employee = Employee::create([
            'name' => $request->name,
            'username' => $request->username,
            'phone' => $request->phone,
            'email' => $request->email,
            'datebirth' => date('Y-m-d', strtotime($request->datebirth)),
            'country' => $request->country,
            'gender' => $request->gender,
            'employment_type_id' => $request->employment_type_id,
            'department_id' => $request->department_id,
            'designation_id' => $request->designation_id,
            'total_leave' => $request->total_leave,
            'salary' => $request->salary,
            'start_working_day' => date('Y-m-d', strtotime($request->start_working_day)),
            'image' => $image_name,
            'created_at' => Carbon::now()->toDateTimeString(),
        ]);

        if ($employee) {
            // Create user account for the employee
            $userController = new RegisteredUserController();
            $userRequest = new Request([
                'name' => $request->name,
                'email' => $request->email,
                'password' => 'password',  // Default password
                'password_confirmation' => 'password',
            ]);

            // Call the store method from RegisteredUserController
            $response = $userController->store($userRequest);

            // Decode the JSON response to get the user ID
            $userData = json_decode($response->getContent());

            // Update the employee record with the user_id
            $employee->user_id = $userData->id;
            $employee->save();

            // If successful, flash a success message and redirect
            Session::flash('success', 'Employee and user created successfully');
            return redirect()->route('employee.index');
        }

        // If employee creation fails, flash an error message
        Session::flash('error', 'Failed to create employee and user');
        return redirect()->back();
    }


    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Employee  $employee
     * @return \Illuminate\Http\Response
     */
    public function show(Employee $employee)
    {
        return view('backend.employee.view', compact('employee'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Employee  $employee
     * @return \Illuminate\Http\Response
     */
    public function edit(Employee $employee)
    {
        // Get additional data for the edit form
        $employmentTypes = EmploymentType::all();
        $departments = Department::all();
        $designations = Designation::all();

        return view('backend.employee.edit', compact('employee', 'employmentTypes', 'departments', 'designations'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Employee  $employee
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Employee $employee)
    {
        // dd($request);
        $request->validate([
            'name' => 'required|string|max:255',
            'username' => 'required|string|max:255|unique:employees,username,' . $employee->id,
            'phone' => 'nullable|numeric',
            'email' => 'required|email|max:100|unique:employees,email,' . $employee->id,
            'datebirth' => 'required|date',
            'country' => 'required',
            'gender' => 'required',
            'employment_type_id' => 'required|exists:employment_types,id',
            'department_id' => 'required|exists:departments,id',
            'designation_id' => 'required|exists:designations,id',
            'total_leave' => 'required',
            'start_working_day' => 'required|date',
            'salary' => 'required',
            'image' => 'nullable|image',
        ]);

        // Handle image upload if present
        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $image_name = time() . '_' . rand(100000, 10000000) . '.' . $image->getClientOriginalExtension();
            Image::make($image)->resize(720, 720)->save('upload/employee/' . $image_name);
            $employee->image = $image_name;
        }

        // Update the employee details
        $employee->update([
            'name' => $request->name,
            'username' => $request->username,
            'phone' => $request->phone,
            'email' => $request->email,
            'datebirth' => date('Y-m-d', strtotime($request->datebirth)),
            'country' => $request->country,
            'gender' => $request->gender,
            'employment_type_id' => $request->employment_type_id,
            'department_id' => $request->department_id,
            'designation_id' => $request->designation_id,
            'total_leave' => $request->total_leave,
            'salary' => $request->salary,
            'start_working_day' => date('Y-m-d', strtotime($request->start_working_day)),
        ]);

        Session::flash('success', 'Employee updated successfully');
        return redirect()->route('employee.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Employee  $employee
     * @return \Illuminate\Http\Response
     */
    public function destroy(Employee $employee)
    {
        $employee->status = 0;
        $employee->save();

        Session::flash('success', 'Employee status changed to inactive successfully');
        return redirect()->route('employee.index');
    }
}

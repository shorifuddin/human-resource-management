<?php $__env->startSection('content'); ?>

<div class="row container">
    <div class="col-md-12 container">
      <div class="card">
        <div class="card-header bg-secondary card_header">
            <div class="row">
              <div class="col-md-8 card_header_title" style="font-weight: 400; font-size:16px;">
                <i class="md md-add-circle "></i> User Information
              </div>
              <div class="col-md-4 card_header_btn ">
                <a href="<?php echo e(url('/dashboard/user/all')); ?>" class="btn btn-xs btn-dark " ><i class="md md-view-module"></i> ALL User </a>
              </div>
            </div>
        </div>

        <div class="card-body">
          <div class="row">
            <div class="col-md-2"></div>
            <div class="col-md-8">
              <table class="table table-bordered table-hover table-striped view_custom_table">
                  <tr>
                    <td>Name</td>
                    <td>:</td>
                    <td><?php echo e($data->name); ?></td>
                  </tr>
                  <tr>
                    <td>Username</td>
                    <td>:</td>
                    <td><?php echo e($data->username); ?></td>
                  </tr>
                  <tr>
                    <td>Email</td>
                    <td>:</td>
                    <td><?php echo e($data->email); ?></td>
                  </tr>
                  <tr>
                    <td>Phone</td>
                    <td>:</td>
                    <td><?php echo e($data->phone); ?></td>
                  </tr>
                  <tr>
                    <td>Birth</td>
                    <td>:</td>
                    <td><?php echo e($data->datebirth); ?></td>
                  </tr>
                  <tr>
                    <td>Country</td>
                    <td>:</td>
                    <td><?php if($data->country==1): ?>
                        Bangladesh
                    <?php elseif($data->country==2): ?>
                        India
                    <?php else: ?>
                        Japan
                    <?php endif; ?></td>
                  </tr>
                  <tr>
                    <td>Gender</td>
                    <td>:</td>
                    <td><?php if($data->gender==1): ?>
                        Male
                    <?php elseif($data->gender==2): ?>
                        Female
                    <?php else: ?>
                        Other
                    <?php endif; ?></td>
                  </tr>
                  <tr>
                    <td>Skill</td>
                    <td>:</td>
                    <td><?php echo e($data->skill); ?></td>
                  </tr>
                  <tr>
                    <td>Category</td>
                    <td>:</td>
                    <td><?php if($data->category == 1): ?>
                        Team Manager
                    <?php else: ?>
                        Worker
                    <?php endif; ?> </td>
                  </tr>
                  <tr>
                    <td>Birth</td>
                    <td>:</td>
                    <td><?php echo $data->about; ?></td>
                  </tr>
                  <tr>
                    <td> Photo</td>
                    <td>:</td>
                    <td>
                      <?php if($data->image!=''): ?>
                        <img class="img-fluid img"  src="<?php echo e(asset('upload/staff/'.$data->image)); ?>">
                      <?php else: ?>
                         <img class="img-fluid img" src="<?php echo e(asset('upload/avater.jpg')); ?>">
                      <?php endif; ?>
                    </td>
                  </tr>
              </table>
            </div>
            <div class="col-md-2"></div>
          </div>
        </div>

      <div class="card-footer bg-secondary card_footer">
        <div class="btn-group" role="group">
          <a type="button" class="btn btn-xs btn-dark">Print</a>
          <a type="button" class="btn btn-xs btn-warning">Excel</a>
          <a type="button" class="btn btn-xs btn-dark">PDF</a>
        </div>
      </div>

      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shorifuddin/Downloads/Laravel-CRUD-main/resources/views/backend/user/viewuser.blade.php ENDPATH**/ ?>
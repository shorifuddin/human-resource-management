<?php
    $today = \Carbon\Carbon::today()->format('Y-m-d');
?>



<?php $__env->startSection('content'); ?>
    <?php if(Session::has('success')): ?>
        <script>
            swal({
                title: "Success",
                text: "The operation completed successfully!",
                icon: "success",
                timer: 3000
            });
        </script>
    <?php endif; ?>

    <?php if(Session::has('error')): ?>
        <script>
            swal({
                title: "Error!",
                text: "There was an error!",
                icon: "error"
            });
        </script>
    <?php endif; ?>

    <div class="row container">
        <div class="col-md-12 container">
            <form method="POST" action="<?php echo e(route('employee.update', $employee->id)); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="card">
                    <div class="card-header bg-secondary card_header">
                        <div class="row">
                            <div class="col-md-8 card_header_title">
                                <i class="md md-add-circle"></i> USER REGISTRATION EDIT NOW
                            </div>
                            <div class="col-md-4 card_header_btn">
                                <a href="<?php echo e(route('alluser')); ?>" class="btn btn-xs btn-dark"
                                    style="float: right; color:white;">
                                    <i class="md md-view-module"></i> All User
                                </a>
                            </div>
                        </div>
                    </div>

                    <div class="card-body">

                        <!-- Name Field -->
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label col_form_label">Name<span
                                    class="req_star">*</span>:</label>
                            <div class="col-sm-7">
                                <input type="text" class="form-control form_control" placeholder="Enter Your Name"
                                    name="name" value="<?php echo e(old('name', $employee->name)); ?>">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <!-- Username Field -->
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label col_form_label">Username<span
                                    class="req_star">*</span>:</label>
                            <div class="col-sm-7">
                                <input type="text" class="form-control form_control" placeholder="Enter Username"
                                    name="username" value="<?php echo e(old('username', $employee->username)); ?>">
                                <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <!-- Phone Field -->
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label col_form_label">Phone:</label>
                            <div class="col-sm-7">
                                <input type="text" class="form-control form_control" placeholder="Enter Phone Number"
                                    name="phone" value="<?php echo e(old('phone', $employee->phone)); ?>">
                                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <!-- Email Field -->
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label col_form_label">Email<span
                                    class="req_star">*</span>:</label>
                            <div class="col-sm-7">
                                <input type="email" class="form-control form_control" placeholder="Enter Email"
                                    name="email" value="<?php echo e(old('email', $employee->email)); ?>">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <!-- Date of Birth Field -->
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label col_form_label">Date of Birth<span
                                    class="req_star">*</span>:</label>
                            <div class="col-sm-7">
                                <input type="date" class="form-control form_control" name="datebirth"
                                    value="<?php echo e(old('datebirth', $employee->datebirth)); ?>">
                                <?php $__errorArgs = ['datebirth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <!-- Country Field -->
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label col_form_label">Country<span
                                    class="req_star">*</span>:</label>
                            <div class="col-sm-7">
                                <select class="form-control form_control" name="country">
                                    <option value="">Choose Country</option>
                                    <option value="Bangladesh"
                                        <?php echo e(old('country', $employee->country) == 'Bangladesh' ? 'selected' : ''); ?>>
                                        Bangladesh</option>
                                    <option value="India"
                                        <?php echo e(old('country', $employee->country) == 'India' ? 'selected' : ''); ?>>India
                                    </option>
                                    <option value="Japan"
                                        <?php echo e(old('country', $employee->country) == 'Japan' ? 'selected' : ''); ?>>Japan
                                    </option>
                                </select>
                                <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <!-- Gender Field -->
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label col_form_label">Gender<span
                                    class="req_star">*</span>:</label>
                            <div class="col-sm-7">
                                <select class="form-control form_control" name="gender">
                                    <option value="">Choose Gender</option>
                                    <option value="Male"
                                        <?php echo e(old('gender', $employee->gender) == 'Male' ? 'selected' : ''); ?>>Male</option>
                                    <option value="Female"
                                        <?php echo e(old('gender', $employee->gender) == 'Female' ? 'selected' : ''); ?>>Female
                                    </option>
                                </select>
                                <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <!-- Employment Type Field -->
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label col_form_label">Employment Type<span
                                    class="req_star">*</span>:</label>
                            <div class="col-sm-7">
                                <select class="form-control form_control" name="employment_type_id">
                                    <option value="">Choose Employment Type</option>
                                    <?php $__currentLoopData = $employmentTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($type->id); ?>"
                                            <?php echo e(old('employment_type_id', $employee->employment_type_id) == $type->id ? 'selected' : ''); ?>>
                                            <?php echo e($type->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['employment_type_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <!-- Department Field -->
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label col_form_label">Department<span
                                    class="req_star">*</span>:</label>
                            <div class="col-sm-7">
                                <select class="form-control form_control" name="department_id">
                                    <option value="">Choose Department</option>
                                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($department->id); ?>"
                                            <?php echo e(old('department_id', $employee->department_id) == $department->id ? 'selected' : ''); ?>>
                                            <?php echo e($department->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['department_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <!-- Designation Field -->
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label col_form_label">Designation<span
                                    class="req_star">*</span>:</label>
                            <div class="col-sm-7">
                                <select class="form-control form_control" name="designation_id">
                                    <option value="">Choose Designation</option>
                                    <?php $__currentLoopData = $designations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($designation->id); ?>"
                                            <?php echo e(old('designation_id', $employee->designation_id) == $designation->id ? 'selected' : ''); ?>>
                                            <?php echo e($designation->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['designation_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <!-- Total Leave Field -->
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label col_form_label">Total Leave:</label>
                            <div class="col-sm-7">
                                <input type="number" class="form-control form_control"
                                    placeholder="Enter Total Leave Number" name="total_leave"
                                    value="<?php echo e(old('total_leave', $employee->total_leave)); ?>">
                                <?php $__errorArgs = ['total_leave'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <!-- Start Working Day Field -->
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label col_form_label">Start Working Date<span
                                    class="req_star">*</span>:</label>
                            <div class="col-sm-7">
                                <input type="date" class="form-control form_control" name="start_working_day"
                                    value="<?php echo e(old('start_working_day', $employee->start_working_day)); ?>">
                                <?php $__errorArgs = ['start_working_day'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <!-- Salary Field -->
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label col_form_label">Salary:</label>
                            <div class="col-sm-7">
                                <input type="number" class="form-control form_control" placeholder="Enter Salary"
                                    name="salary" value="<?php echo e(old('salary', $employee->salary)); ?>">
                                <?php $__errorArgs = ['salary'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <!-- Image Field -->
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label col_form_label">Profile Image:</label>
                            <div class="col-sm-7">
                                <input type="file" class="form-control form_control" name="image">
                                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <img src="<?php echo e(asset('upload/employee/' . $employee->image)); ?>" alt="Profile Image"
                                    style="width: 100px; margin-top: 10px;">
                            </div>
                        </div>

                    </div>

                    <div class="card-footer bg-secondary card_footer">
                        <button type="submit" class="btn btn-dark">UPDATE</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shorifuddin/Downloads/Laravel-CRUD-main/resources/views/backend/employee/edit.blade.php ENDPATH**/ ?>
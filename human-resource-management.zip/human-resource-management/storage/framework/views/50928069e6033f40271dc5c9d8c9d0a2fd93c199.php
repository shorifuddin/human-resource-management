<?php $__env->startSection('content'); ?>
    <?php if(Session::has('success')): ?>
        <script>
            swal({
                title: "Good job!",
                text: "The operation completed successfully!",
                icon: "success",
                timer: 3000,
            });
        </script>
    <?php endif; ?>

    <?php if(Session::has('error')): ?>
        <script>
            swal({
                title: "Good error!",
                text: "You clicked the button!",
                icon: "error",
            });
        </script>
    <?php endif; ?>

    <div class="row container">
        <div class="col-md-12 container">
            <form method="POST" action="<?php echo e(route('update', $data->staff_id)); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="card">
                    <div class="card-header bg-secondary card_header">
                        <div class="row">
                            <div class="col-md-8 card_header_title">
                                <i class="md md-add-circle"></i> USER UPDATE NOW
                            </div>
                            <div class="col-md-4 card_header_btn ">
                                <a href="<?php echo e(route('alluser')); ?>" class="btn btn-xs btn-dark "
                                    style="float: right; color:white;"><i class="md md-view-module"></i> All User</a>
                            </div>
                        </div>
                    </div>

                    <div class="card-body">
                        <input type="hidden" name="id" value="<?php echo e($data->staff_id); ?>">

                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label col_form_label">Name<span
                                    class="req_star">*</span>:</label>
                            <div class="col-sm-7">
                                <input type="text" class="form-control form_control" name="name"
                                    value="<?php echo e($data->name); ?>">
                                <span class="invalid-feedback">
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </span>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label col_form_label">Phone:</label>
                            <div class="col-sm-7 pp">
                                <input type="text" class="form-control form_control" name="phone"
                                    value="<?php echo e($data->phone); ?>">
                                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <?php echo e($message); ?>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row ">
                            <label class="col-sm-3 col-form-label col_form_label">Username<span
                                    class="req_star">*</span>:</label>
                            <div class="col-sm-7 pp">
                                <div class="input-group">
                                    <div class="input-group-text">@</div>
                                    <input type="text" class="form-control" id="autoSizingInputGroup"
                                        placeholder="Username" name="username" value="<?php echo e($data->username); ?>">
                                </div>
                                <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"> <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                                </span>
                            </div>
                        </div>


                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label col_form_label">Email<span
                                    class="req_star">*</span>:</label>
                            <div class="col-sm-7 pp">
                                <input type="email" class="form-control form_control" name="email"
                                    value="<?php echo e($data->email); ?>">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <?php echo e($message); ?>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label col_form_label">Date Of Birth<span
                                    class="req_star">*</span>:</label>
                            <div class="col-sm-7 pp">
                                <div class="input-group" id="datepicker1">
                                    <input type="text" class="form-control" placeholder="dd M, yyyy"
                                        data-date-format="dd M, yyyy" data-date-container="#datepicker1"
                                        data-provide="datepicker" name="datebirth" value="<?php echo e($data->datebirth); ?>">
                                    <span class="input-group-text"><i class="mdi mdi-calendar"></i></span>
                                </div>
                                <?php $__errorArgs = ['datebirth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"> <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label col_form_label">Country<span
                                    class="req_star">*</span>:</label>
                            <div class="col-sm-4">
                                <select class="form-control form_control" name="country">
                                    <option value="1" <?php echo e($data->country == 1 ? 'selected' : ''); ?>>Bangladesh</option>
                                    <option value="2" <?php echo e($data->country == 2 ? 'selected' : ''); ?>>India</option>
                                    <option value="3" <?php echo e($data->country == 3 ? 'selected' : ''); ?>>Japan</option>
                                </select>
                                <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"> <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                            </div>
                        </div>

                        <div class="row">
                            <label class="col-sm-3 col-form-label col_form_label">Gender<span
                                    class="req_star">*</span>:</label>
                            <div class="col-sm-7 pp">
                                <input class="form-check-input" type="radio" id="formRadios1"
                                    <?php echo e($data->gender == 1 ? 'checked' : ''); ?> value="1" name="gender">
                                <label class="form-check-label" for="formRadios2"> Male </label>
                                <input class="form-check-input" type="radio" id="formRadios2"
                                    <?php echo e($data->gender == 2 ? 'checked' : ''); ?> value="2" name="gender">
                                <label class="form-check-label" for="formRadios2"> Female </label>
                                <input class="form-check-input" type="radio" id="formRadios3"
                                    <?php echo e($data->gender == 3 ? 'checked' : ''); ?> value="3" name="gender">
                                <label class="form-check-label" for="formRadios2"> Other </label>
                                <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"> <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                            </div>
                        </div>

                        <?php
                            $skill = explode(',', $data->skill);
                        ?>

                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label col_form_label">Skill<span
                                    class="req_star">*</span>:</label>
                            <div class="col-sm-7 pp mt-2">
                                <input class="form-check-input" type="checkbox" id="formCheck1" name="skill[]"
                                    value="php" <?php echo e(in_array('php', $skill) ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="formCheck1">PHP</label>

                                <input class="form-check-input" type="checkbox" id="formCheck1" name="skill[]"
                                    value="laravel" <?php echo e(in_array('laravel', $skill) ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="formCheck1">Laravel</label>

                                <input class="form-check-input" type="checkbox" id="formCheck1" name="skill[]"
                                    value="java" <?php echo e(in_array('java', $skill) ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="formCheck1">JavaScript</label>

                                <input class="form-check-input" type="checkbox" id="formCheck1" name="skill[]"
                                    value="js" <?php echo e(in_array('js', $skill) ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="formCheck1">JQuery</label>
                                <?php $__errorArgs = ['skill'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"> <?php echo e($message); ?> </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>


                        <div class="form-switch row">
                            <label class="col-sm-3 col-form-label col_form_label">Category <span
                                    class="req_star">*</span>:</label>
                            <div class="col-sm-7 pp">
                                <input type="hidden" name="category" value="0">
                                <div class="form-check form-switch mt-2">
                                    <input class="form-check-input" type="checkbox" id="flexSwitchCheckDefault1"
                                        <?php echo e($data->category == 1 ? 'checked' : ''); ?> name="category" value="1">
                                    <label class="form-check-label" for="flexSwitchCheckDefault1">Line Manager</label>
                                </div>
                                <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>


                        <div class="form-group row ">
                            <label class="col-sm-3 col-form-label col_form_label">About or Details :</label>
                            <div class="col-sm-7">
                                <textarea class="summernote form-control form_control" name="about"><?php echo $data->about; ?></textarea>
                                <?php $__errorArgs = ['about'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"> <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label col_form_label">Photo:</label>
                            <div class="col-sm-7 ">
                                <input type="file" name="image" value="<?php echo e($data->image); ?>">
                                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"> <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
                                <?php if($data->image != ''): ?>
                                    <img class="img-fluid img" src="<?php echo e(asset('upload/staff/' . $data->image)); ?>">
                                <?php else: ?>
                                    <img class="img-fluid img" src="<?php echo e(asset('upload/avater.jpg')); ?>">
                                <?php endif; ?>

                            </div>
                        </div>
                    </div>

                    <div class="card-footer bg-secondary card_footer">
                        <button type="submit" class="btn btn-dark">Update User</button>
                    </div>

                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('couston_js'); ?>
    <!-- bundle -->
    <script src="<?php echo e(asset('backend')); ?>/assets/libs/select2/js/select2.min.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/assets/libs/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/assets/libs/spectrum-colorpicker2/spectrum.min.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/assets/libs/bootstrap-timepicker/js/bootstrap-timepicker.min.js"></script>

    <script src="<?php echo e(asset('backend/assets')); ?>/plugins/bootstrap-wysihtml5/wysihtml5-0.3.0.js"></script>
    <script src="<?php echo e(asset('backend/assets')); ?>/plugins/bootstrap-wysihtml5/bootstrap-wysihtml5.js"></script>

    <!--form validation init-->
    <script src="<?php echo e(asset('backend/assets')); ?>/plugins/summernote/summernote-bs4.js"></script>

    <script>
        jQuery(document).ready(function() {
            $('.wysihtml5').wysihtml5();

            $('.summernote').summernote({
                height: 200, // set editor height

                minHeight: null, // set minimum height of editor
                maxHeight: null, // set maximum height of editor

                focus: true // set focus to editable area after initializing summernote
            });

        });
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('couston_CSS'); ?>
    <!--bootstrap-wysihtml5-->
    <link rel="stylesheet" type="text/css"
        href="<?php echo e(asset('backend/assets')); ?>/plugins/bootstrap-wysihtml5/bootstrap-wysihtml5.css">
    <link href="<?php echo e(asset('backend/assets')); ?>/plugins/summernote/summernote-bs4.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shorifuddin/Downloads/Laravel-CRUD-main/resources/views/backend/user/edituser.blade.php ENDPATH**/ ?>
<?php
    $today = \Carbon\Carbon::today()->format('Y-m-d');
?>

<?php $__env->startSection('content'); ?>
    <?php if(Session::has('success')): ?>
        <script>
            swal({
                title: "Success",
                text: "The operation completed successfully!",
                icon: "success",
                timer: 3000
            });
        </script>
    <?php endif; ?>

    <?php if(Session::has('error')): ?>
        <script>
            swal({
                title: "Error!",
                text: "There was an error!",
                icon: "error"
            });
        </script>
    <?php endif; ?>

    <div class="row container">
        <div class="col-md-12 container">
            <form method="POST" action="<?php echo e(route('employee.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="card">
                    <div class="card-header bg-secondary card_header">
                        <div class="row">
                            <div class="col-md-8 card_header_title">
                                <i class="md md-add-circle"></i> User REGISTRATION NOW
                            </div>
                            <div class="col-md-4 card_header_btn">
                                <a href="<?php echo e(route('alluser')); ?>" class="btn btn-xs btn-dark"
                                    style="float: right; color:white;">
                                    <i class="md md-view-module"></i> All User
                                </a>
                            </div>
                        </div>
                    </div>

                    <div class="card-body">

                        <!-- Name Field -->
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label col_form_label">Name<span
                                    class="req_star">*</span>:</label>
                            <div class="col-sm-7">
                                <input type="text" class="form-control form_control" placeholder="Enter Your Name"
                                    name="name" value="<?php echo e(old('name')); ?>">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <!-- Username Field -->
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label col_form_label">Username<span
                                    class="req_star">*</span>:</label>
                            <div class="col-sm-7">
                                <input type="text" class="form-control form_control" placeholder="Enter Username"
                                    name="username" value="<?php echo e(old('username')); ?>">
                                <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <!-- Phone Field -->
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label col_form_label">Phone:</label>
                            <div class="col-sm-7">
                                <input type="text" class="form-control form_control" placeholder="Enter Phone Number"
                                    name="phone" value="<?php echo e(old('phone')); ?>">
                                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <!-- Email Field -->
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label col_form_label">Email<span
                                    class="req_star">*</span>:</label>
                            <div class="col-sm-7">
                                <input type="email" class="form-control form_control" placeholder="Enter Email"
                                    name="email" value="<?php echo e(old('email')); ?>">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <!-- Date of Birth Field -->
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label col_form_label">Date of Birth<span
                                    class="req_star">*</span>:</label>
                            <div class="col-sm-7">
                                <input type="date" class="form-control form_control" name="datebirth"
                                    value="<?php echo e(old('datebirth')); ?>">
                                <?php $__errorArgs = ['datebirth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <!-- Country Field -->
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label col_form_label">Country<span
                                    class="req_star">*</span>:</label>
                            <div class="col-sm-7">
                                <select class="form-control form_control" name="country">
                                    <option>Choose Country</option>
                                    <option value="Bangladesh">Bangladesh</option>
                                    <option value="India">India</option>
                                    <option value="Japan">Japan</option>
                                </select>
                                <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <!-- Gender Field -->
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label col_form_label">Gender<span
                                    class="req_star">*</span>:</label>
                            <div class="col-sm-7">
                                <select class="form-control form_control" name="gender">
                                    <option value="">Choose Gender</option>
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                </select>
                                <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <!-- Employment Type Field -->
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label col_form_label">Employment Type<span
                                    class="req_star">*</span>:</label>
                            <div class="col-sm-7">
                                <select class="form-control form_control" name="employment_type_id">
                                    <option value="">Choose Employment Type</option>
                                    <?php $__currentLoopData = $employmentTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($type->id); ?>"><?php echo e($type->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['employment_type_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <!-- Department Field -->
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label col_form_label">Department<span
                                    class="req_star">*</span>:</label>
                            <div class="col-sm-7">
                                <select class="form-control form_control" name="department_id">
                                    <option value="">Choose Department</option>
                                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($department->id); ?>"><?php echo e($department->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['department_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <!-- Designation Field -->
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label col_form_label">Designation<span
                                    class="req_star">*</span>:</label>
                            <div class="col-sm-7">
                                <select class="form-control form_control" name="designation_id">
                                    <option value="">Choose Designation</option>
                                    <?php $__currentLoopData = $designations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($designation->id); ?>"><?php echo e($designation->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['designation_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <!-- Total leave Field -->
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label col_form_label">Total Leave:</label>
                            <div class="col-sm-7">
                                <input type="number" class="form-control form_control"
                                    placeholder="Enter Total Leave Number" name="total_leave"
                                    value="<?php echo e(old('total_leave'), 14); ?>">
                                <?php $__errorArgs = ['total_leave'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <!-- start_working_day Field -->
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label col_form_label">Start Working Date<span
                                    class="req_star">*</span>:</label>
                            <div class="col-sm-7">
                                <input type="date" class="form-control form_control" name="start_working_day"
                                    value="<?php echo e(old('start_working_day', $today)); ?>">
                                <?php $__errorArgs = ['start_working_day'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <!-- Salary Field -->
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label col_form_label">Salary:</label>
                            <div class="col-sm-7">
                                <input type="number" class="form-control form_control"
                                    placeholder="Enter Salary" name="salary" value="<?php echo e(old('salary')); ?>">
                                <?php $__errorArgs = ['salary'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <!-- Image Field -->
                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label col_form_label">Profile Image:</label>
                            <div class="col-sm-7">
                                <input type="file" class="form-control form_control" name="image">
                                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                    </div>

                    <div class="card-footer bg-secondary card_footer">
                        <button type="submit" class="btn btn-dark">REGISTRATION</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shorifuddin/Downloads/Laravel-CRUD-main/resources/views/backend/employee/add.blade.php ENDPATH**/ ?>
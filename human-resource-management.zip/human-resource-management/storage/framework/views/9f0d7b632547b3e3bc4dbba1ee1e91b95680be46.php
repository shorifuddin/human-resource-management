<?php $__env->startSection('content'); ?>
<div class="row container">
    <div class="col-md-12 container">
      <div class="card">
        <div class="card-header bg-secondary card_header">
            <div class="row">
              <div class="col-md-8 card_header_title" style="font-weight: 400; font-size:16px;">
                <i class="md md-add-circle "></i> Employee Information
              </div>
              <div class="col-md-4 card_header_btn ">
                <a href="<?php echo e(route('employee.index')); ?>" class="btn btn-xs btn-dark"><i class="md md-view-module"></i> All Employees </a>
              </div>
            </div>
        </div>

        <div class="card-body">
          <div class="row">
            <div class="col-md-2"></div>
            <div class="col-md-8">
              <table class="table table-bordered table-hover table-striped view_custom_table">
                  <tr>
                    <td>Name</td>
                    <td>:</td>
                    <td><?php echo e($employee->name); ?></td>
                  </tr>
                  <tr>
                    <td>Username</td>
                    <td>:</td>
                    <td><?php echo e($employee->username); ?></td>
                  </tr>
                  <tr>
                    <td>Birth</td>
                    <td>:</td>
                    <td><?php echo e($employee->datebirth); ?></td>
                  </tr>
                  <tr>
                    <td>Email</td>
                    <td>:</td>
                    <td><?php echo e($employee->email); ?></td>
                  </tr>
                  <tr>
                    <td>Phone</td>
                    <td>:</td>
                    <td><?php echo e($employee->phone); ?></td>
                  </tr>
                  <tr>
                    <td>Country</td>
                    <td>:</td>
                    <td><?php echo e($employee->country); ?></td>
                  </tr>
                  <tr>
                    <td>Gender</td>
                    <td>:</td>
                    <td><?php echo e($employee->gender); ?></td>
                  </tr>
                  <tr>
                    <td>Employment Type</td>
                    <td>:</td>
                    <td><?php echo e($employee->employmentType->name); ?></td>
                  </tr>
                  <tr>
                    <td>Department</td>
                    <td>:</td>
                    <td><?php echo e($employee->department->name); ?></td>
                  </tr>
                  <tr>
                    <td>Designation</td>
                    <td>:</td>
                    <td><?php echo e($employee->designation->name); ?></td>
                  </tr>
                  <tr>
                    <td>Total Leave</td>
                    <td>:</td>
                    <td><?php echo e($employee->total_leave); ?></td>
                  </tr>
                  <tr>
                    <td>Start Working Day</td>
                    <td>:</td>
                    <td><?php echo e($employee->start_working_day); ?></td>
                  </tr>
                  <tr>
                    <td>Salary</td>
                    <td>:</td>
                    <td><?php echo e($employee->salary); ?></td>
                  </tr>
                  <tr>
                    <td>Image</td>
                    <td>:</td>
                    <td>
                      <?php if(!empty($employee->image)): ?>
                        <img src="<?php echo e(asset('upload/employee/' . $employee->image)); ?>" alt="Image" width="100">
                      <?php else: ?>
                        <img src="<?php echo e(asset('upload/avater.jpg')); ?>" alt="Image" width="100">
                      <?php endif; ?>
                    </td>
                  </tr>
              </table>
            </div>
            <div class="col-md-2"></div>
          </div>
        </div>

      <div class="card-footer bg-secondary card_footer">
        <div class="btn-group" role="group">
          <a type="button" class="btn btn-xs btn-dark">Print</a>
          <a type="button" class="btn btn-xs btn-warning">Excel</a>
          <a type="button" class="btn btn-xs btn-dark">PDF</a>
        </div>
      </div>

      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shorifuddin/Downloads/Laravel-CRUD-main/resources/views/backend/employee/view.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
    <div class="col-xl-12">
        <div class="row">

            <div class="col-xl-6">
                <div class="card overflow-hidden">
                    <div class="bg-soft-primary" style="background-color:#c4ccff !important;">
                        <div class="row">
                            <div class="col-7">
                                <div class="text-primary p-3">
                                    <h5 class="text-primary">Welcome!</h5>
                                    <p>Today Dashboard</p>
                                </div>
                            </div>
                            <div class="col-5 align-self-end">
                                <img src="<?php echo e(asset('backend/assets/images/profile-img.png')); ?>" alt=""
                                    class="img-fluid">
                            </div>
                        </div>
                    </div>
                    <div class="card-body pt-0">
                        <div class="row">
                            <div class="col-sm-4">
                                <div class="avatar-md profile-user-wid mb-4">
                                    <img src="<?php echo e(Auth::user()->employee && Auth::user()->employee->image
                                        ? asset('upload/employee/' . Auth::user()->employee->image)
                                        : asset('backend/assets/images/users/avatar-1.jpg')); ?>"
                                        alt="Profile Image" class="img-thumbnail rounded-circle">
                                </div>
                                <h5 class="font-size-15 text-truncate"><?php echo e(Auth::user()->name); ?></h5>
                                <!-- Check if the user has an associated employee and employee has a designation -->
                                <?php if(Auth::user()->employee && Auth::user()->employee->designation): ?>
                                    <p class="text-muted mb-0 text-truncate"><?php echo e(Auth::user()->employee->designation->name); ?>

                                    </p>
                                <?php else: ?>
                                    <p class="text-muted mb-0 text-truncate">Designatio Not Assigned</p>
                                <?php endif; ?>
                            </div>

                            <div class="col-sm-8">
                                <div class="pt-4">
                                    <div class="row">
                                        <div class="col-6">
                                            <h5 class="font-size-15"><?php echo e($department); ?></h5>
                                            <p class="text-muted mb-0">Department</p>
                                        </div>
                                        <div class="col-6">
                                            <h5 class="font-size-15"><?php echo e($employmentType); ?></h5>
                                            <p class="text-muted mb-0">Employment Type</p>
                                        </div>
                                    </div>
                                    <div class="mt-4">
                                        <?php
                                            $todayAttendance = \App\Models\Attendance::where('employee_id', Auth::id())
                                                ->whereDate('check_in_date_time', \Carbon\Carbon::today())
                                                ->first();
                                        ?>

                                        <?php if(!$todayAttendance): ?>
                                            
                                            <form action="<?php echo e(route('attendance.checkin')); ?>" method="POST"
                                                style="display: inline;">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit"
                                                    class="btn btn-primary waves-effect waves-light btn-sm">
                                                    Check In <i class="bx bx-fingerprint ml-1"></i>
                                                </button>
                                            </form>
                                        <?php elseif($todayAttendance && !$todayAttendance->check_out_date_time): ?>
                                            
                                            <form action="<?php echo e(route('attendance.checkout', $todayAttendance->id)); ?>"
                                                method="POST" style="display: inline;">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit"
                                                    class="btn btn-danger waves-effect waves-light btn-sm">
                                                    Check Out <i class="fas fa-fingerprint ml-1"></i>
                                                </button>
                                            </form>
                                        <?php else: ?>
                                            
                                            <p class="text-muted mb-0">You have already checked in and checked out today.
                                            </p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-6">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title mb-5">Activity</h4>
                        <ul class="verti-timeline list-unstyled">
                            <li class="event-list active">
                                <div class="event-timeline-dot">
                                    <i class="bx bxs-right-arrow-circle font-size-18 bx-fade-right"></i>
                                </div>
                                <div class="media">
                                    <div class="mr-3">
                                        <h5 class="font-size-14">Today <i
                                                class="bx bx-right-arrow-alt font-size-16 text-primary align-middle ml-2"></i>
                                        </h5>
                                    </div>
                                    <div class="media-body">
                                        <div>
                                            Joined the group “Boardsmanship Forum”
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li class="event-list">
                                <div class="event-timeline-dot">
                                    <i class="bx bx-right-arrow-circle font-size-18"></i>
                                </div>
                                <div class="media">
                                    <div class="mr-3">
                                        <h5 class="font-size-14">Next Day <i
                                                class="bx bx-right-arrow-alt font-size-16 text-primary align-middle ml-2"></i>
                                        </h5>
                                    </div>
                                    <div class="media-body">
                                        <div>
                                            Responded to need “In-Kind Opportunity”
                                        </div>
                                    </div>
                                </div>
                            </li>
                        </ul>
                        <div class="text-center mt-4"><a href=""
                                class="btn btn-primary waves-effect waves-light btn-sm">View More <i
                                    class="mdi mdi-arrow-right ml-1"></i></a></div>
                    </div>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="card mini-stats-wid">
                    <div class="card-body">
                        <div class="d-flex flex-wrap">
                            <div class="me-3">
                                <p class="text-muted mb-2">Total Employee</p>
                                <h5 class="mb-0"><?php echo e($totalEmployees); ?></h5>
                            </div>

                            <div class="avatar-sm ms-auto">
                                <div class="avatar-title bg-light rounded-circle text-primary font-size-20">
                                    <i class="bx bxs-book-bookmark"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="card blog-stats-wid">
                    <div class="card-body">
                        <div class="d-flex flex-wrap">
                            <div class="me-3">
                                <p class="text-muted mb-2">Total Leave Available</p>
                                <h5 class="mb-0"><?php echo e($totalLeaveAvailable); ?></h5>
                            </div>

                            <div class="avatar-sm ms-auto">
                                <div class="avatar-title bg-light rounded-circle text-primary font-size-20">
                                    <i class="bx bxs-note"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="card blog-stats-wid">
                    <div class="card-body">
                        <div class="d-flex flex-wrap">
                            <div class="me-3">
                                <p class="text-muted mb-2">Total Department</p>
                                <h5 class="mb-0"><?php echo e($totalDepartments); ?></h5>
                            </div>

                            <div class="avatar-sm ms-auto">
                                <div class="avatar-title bg-light rounded-circle text-primary font-size-20">
                                    <i class="bx bxs-message-square-dots"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <!-- end row -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shorifuddin/Downloads/Laravel-CRUD-main/resources/views/backend/admin/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
    <?php if(Session::has('success')): ?>
        <script>
            swal({
                title: "Good job!",
                text: "The operation completed successfully!",
                icon: "success",
                timer: 3000,
            });
        </script>
    <?php endif; ?>

    <?php if(Session::has('error')): ?>
        <script>
            swal({
                title: "Error!",
                text: "There was a problem with the operation.",
                icon: "error",
            });
        </script>
    <?php endif; ?>

    <br>
    <div class="row container">
        <div class="col-md-12 container">
            <div class="card">
                <div class="card-header bg-secondary card_header">
                    <div class="row">
                        <div class="col-md-8 card_header_title">
                            <i class="md md-add-circle "></i> All Leave Requests
                        </div>
                        <div class="col-md-4 card_header_btn">
                            <a href="<?php echo e(route('leave-request.create')); ?>" class="btn btn-xs btn-dark"
                                style="float: right; color:white;"><i class="md md-view-module"></i> Add Leave Request</a>
                        </div>
                    </div>
                </div>

                <br>
                <div class="tab-content">
                    <div class="tab-pane show active" id="basic-datatable-preview">
                        <div class="table-responsive">
                            <table id="datatable-buttons" class="table table-bordered dt-responsive nowrap w-100">
                                <thead>
                                    <tr>
                                        <th>Leave Type</th>
                                        <th>Start Date</th>
                                        <th>End Date</th>
                                        <th>Status</th>
                                        <th>Manage</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $alldata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($data->leaveType->name); ?></td>
                                            <td><?php echo e($data->start_date); ?></td>
                                            <td><?php echo e($data->end_date); ?></td>
                                            <td>
                                                <?php if($data->status == 1): ?>
                                                    Pending
                                                <?php elseif($data->status == 2): ?>
                                                    Process
                                                <?php elseif($data->status == 3): ?>
                                                    Approved
                                                <?php elseif($data->status == 4): ?>
                                                    Rejected
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <div class="btn-group">
                                                    <button type="button" class="btn btn-dark dropdown-toggle"
                                                        data-bs-toggle="dropdown" aria-expanded="false">
                                                        Manage <span class="caret"></span>
                                                    </button>
                                                    <div class="dropdown-menu">
                                                        <?php if($data->status == 1): ?>
                                                            <a class="dropdown-item"
                                                                href="<?php echo e(route('leaveRequest.updateStatus', ['id' => $data->id, 'status' => 2])); ?>">Process</a>
                                                        <?php endif; ?>
                                                        <?php if($data->status == 2): ?>
                                                            <a class="dropdown-item"
                                                                href="<?php echo e(route('leaveRequest.updateStatus', ['id' => $data->id, 'status' => 3])); ?>">Approve</a>
                                                            <a class="dropdown-item"
                                                                href="<?php echo e(route('leaveRequest.updateStatus', ['id' => $data->id, 'status' => 4])); ?>">Reject</a>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="card-footer bg-secondary card_footer">
                    <div class="btn-group" role="group">
                        <a type="button" class="btn btn-xs btn-dark">Print</a>
                        <a type="button" class="btn btn-xs btn-warning">Excel</a>
                        <a type="button" class="btn btn-xs btn-dark">PDF</a>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('couston_CSS'); ?>
    <!-- DataTables -->
    <link href="<?php echo e(asset('backend/assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('backend/assets/libs/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css')); ?>"
        rel="stylesheet">
    <link href="<?php echo e(asset('backend/assets/libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css')); ?>"
        rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('couston_js'); ?>
    <!-- Required datatable js -->
    <script src="<?php echo e(asset('backend/assets/libs/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/assets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/assets/libs/datatables.net-buttons/js/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/assets/libs/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/assets/libs/datatables.net-responsive/js/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/assets/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js')); ?>">
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shorifuddin/Downloads/Laravel-CRUD-main/resources/views/backend/leaveRequest/all.blade.php ENDPATH**/ ?>
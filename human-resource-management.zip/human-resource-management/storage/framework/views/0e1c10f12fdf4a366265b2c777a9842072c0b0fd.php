<?php $__env->startSection('content'); ?>

<?php if(Session::has('success')): ?>
<script>
swal({ title: "Success",text: "The operation completed successfully!", icon: "success",timer:3000,});
</script>
<?php endif; ?>

<?php if(Session::has('error')): ?>
<script>
swal({ title: "Error!",text: "You clicked the button!", icon: "error",});
</script>
<?php endif; ?>

<div class="row container">
    <div class="col-md-12 container">
      <form method="POST" action="<?php echo e(route('leaveType.store')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
       <div class="card">
        <div class="card-header bg-secondary card_header">
            <div class="row">
              <div class="col-md-8 card_header_title">
                <i class="md md-add-circle"></i> Student REGISTRATION NOW
              </div>
              <div class="col-md-4 card_header_btn ">
              <a href="<?php echo e(route('leaveType.index')); ?>" class="btn btn-xs btn-dark " style="float: right; color:white;"><i class="md md-view-module"></i> All Student</a>
             </div>
            </div>
        </div>

        <div class="card-body ">

          <div class="form-group row ">
            <label class="col-sm-3 col-form-label col_form_label">Name<span class="req_star">*</span>:</label>
            <div class="col-sm-7 pp">
              <input type="text" class="form-control form_control" placeholder="Enter Your Name" name="name" value="<?php echo e(old('name')); ?>">
              <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger">  <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> </span>
            </div>
          </div>

      <div class="card-footer bg-secondary card_footer">
        <button type="submit" class="btn btn-dark">REGISTRATION</button>
      </div>

      </div>
    </form>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('couston_js'); ?>
<!-- bundle -->
        <script src="<?php echo e(asset('backend')); ?>/assets/libs/select2/js/select2.min.js"></script>
        <script src="<?php echo e(asset('backend')); ?>/assets/libs/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>
        <script src="<?php echo e(asset('backend')); ?>/assets/libs/spectrum-colorpicker2/spectrum.min.js"></script>
        <script src="<?php echo e(asset('backend')); ?>/assets/libs/bootstrap-timepicker/js/bootstrap-timepicker.min.js"></script>

        <script src="<?php echo e(asset('backend/assets')); ?>/plugins/bootstrap-wysihtml5/wysihtml5-0.3.0.js"></script>
        <script src="<?php echo e(asset('backend/assets')); ?>/plugins/bootstrap-wysihtml5/bootstrap-wysihtml5.js"></script>

<!--form validation init-->
<script src="<?php echo e(asset('backend/assets')); ?>/plugins/summernote/summernote-bs4.js"></script>

<script>

    jQuery(document).ready(function(){
        $('.wysihtml5').wysihtml5();

        $('.summernote').summernote({
            height: 200,                 // set editor height

            minHeight: null,             // set minimum height of editor
            maxHeight: null,             // set maximum height of editor

            focus: true                 // set focus to editable area after initializing summernote
        });

    });
</script>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('couston_CSS'); ?>
<!--bootstrap-wysihtml5-->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend/assets')); ?>/plugins/bootstrap-wysihtml5/bootstrap-wysihtml5.css">
<link href="<?php echo e(asset('backend/assets')); ?>/plugins/summernote/summernote-bs4.css" rel="stylesheet">

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shorifuddin/Downloads/Laravel-CRUD-main/resources/views/backend/leaveType/add.blade.php ENDPATH**/ ?>
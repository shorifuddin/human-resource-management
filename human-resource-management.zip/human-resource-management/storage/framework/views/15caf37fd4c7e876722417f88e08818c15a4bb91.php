<?php
    $today = \Carbon\Carbon::today()->format('Y-m-d');
    $tomorrow = \Carbon\Carbon::tomorrow()->format('Y-m-d');
?>


<?php $__env->startSection('content'); ?>
    <?php if(Session::has('success')): ?>
        <script>
            swal({
                title: "Success",
                text: "The operation completed successfully!",
                icon: "success",
                timer: 3000,
            });
        </script>
    <?php endif; ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>


    <?php if(Session::has('error')): ?>
        <script>
            swal({
                title: "Error!",
                text: "You clicked the button!",
                icon: "error",
            });
        </script>
    <?php endif; ?>

    <div class="row container">
        <div class="col-md-12 container">
            <form method="POST" action="<?php echo e(route('leave-request.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="card">
                    <div class="card-header bg-secondary card_header">
                        <div class="row">
                            <div class="col-md-8 card_header_title">
                                <i class="md md-add-circle"></i> Student REGISTRATION NOW
                            </div>
                            <div class="col-md-4 card_header_btn">
                                <a href="<?php echo e(route('leave-request.index')); ?>" class="btn btn-xs btn-dark"
                                    style="float: right; color:white;"><i class="md md-view-module"></i> All Student</a>
                            </div>
                        </div>
                    </div>

                    <div class="card-body">
                        <div class="form-group row">
                            <label class="col-md-2 col-form-label col_form_label">Leave Type <span
                                    class="req_star">*</span>: </label>
                            <div class="col-md-10">
                                <select class="form-control" name="leave_type_id">
                                    <option value="">Select</option>
                                    <?php $__currentLoopData = $leaveTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leaveType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($leaveType->id); ?>"><?php echo e($leaveType->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="start_date" class="col-md-2 col-form-label col_form_label">Start Date <span
                                    class="req_star">*</span>: </label>
                            <div class="col-md-10">
                                <input class="form-control" type="date" name="start_date" value="<?php echo e(old('start_date', $today)); ?>" id="start_date">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="end_date" class="col-md-2 col-form-label col_form_label">End Date <span
                                    class="req_star">*</span>: </label>
                            <div class="col-md-10">
                                <input class="form-control" type="date" name="end_date" value="<?php echo e($tomorrow); ?>"
                                    id="end_date">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="request_day" class="col-md-2 col-form-label col_form_label">Number Of Days
                                <span class="req_star">*</span>: </label>
                            <div class="col-md-10">
                                <input class="form-control" type="tel" name="request_day" value="1"
                                    id="request_day">
                            </div>
                        </div>

                        <div class="card-footer bg-secondary card_footer">
                            <button type="submit" class="btn btn-dark">REGISTRATION</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('couston_js'); ?>
    <!-- bundle -->
    <script src="<?php echo e(asset('backend')); ?>/assets/libs/select2/js/select2.min.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/assets/libs/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/assets/libs/spectrum-colorpicker2/spectrum.min.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/assets/libs/bootstrap-timepicker/js/bootstrap-timepicker.min.js"></script>
    <script src="<?php echo e(asset('backend/assets')); ?>/plugins/bootstrap-wysihtml5/wysihtml5-0.3.0.js"></script>
    <script src="<?php echo e(asset('backend/assets')); ?>/plugins/bootstrap-wysihtml5/bootstrap-wysihtml5.js"></script>

    <!--form validation init-->
    <script src="<?php echo e(asset('backend/assets')); ?>/plugins/summernote/summernote-bs4.js"></script>

    <script>
        jQuery(document).ready(function() {
            $('.wysihtml5').wysihtml5();

            $('.summernote').summernote({
                height: 200, // set editor height

                minHeight: null, // set minimum height of editor
                maxHeight: null, // set maximum height of editor

                focus: true // set focus to editable area after initializing summernote
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('couston_CSS'); ?>
    <!--bootstrap-wysihtml5-->
    <link rel="stylesheet" type="text/css"
        href="<?php echo e(asset('backend/assets')); ?>/plugins/bootstrap-wysihtml5/bootstrap-wysihtml5.css">
    <link href="<?php echo e(asset('backend/assets')); ?>/plugins/summernote/summernote-bs4.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shorifuddin/Downloads/Laravel-CRUD-main/resources/views/backend/leaveRequest/add.blade.php ENDPATH**/ ?>
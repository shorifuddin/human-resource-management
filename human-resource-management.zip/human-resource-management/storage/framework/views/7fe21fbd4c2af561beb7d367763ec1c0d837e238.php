<?php $__env->startSection('content'); ?>
    <?php if(Session::has('success')): ?>
        <script>
            swal({
                title: "Good job!",
                text: "The operation completed successfully!",
                icon: "success",
                timer: 3000,
            });
        </script>
    <?php endif; ?>

    <?php if(Session::has('error')): ?>
        <script>
            swal({
                title: "Error!",
                text: "There was a problem with the operation.",
                icon: "error",
            });
        </script>
    <?php endif; ?>

    <br>
    <div class="row container">
        <div class="col-md-12 container">
            <div class="card">
                <div class="card-header bg-secondary card_header">
                    <div class="row">
                        <div class="col-md-8 card_header_title">
                            <i class="md md-add-circle"></i> Leave Balances
                        </div>
                        <div class="col-md-4 card_header_btn">
                            <a href="<?php echo e(route('leave-balance.create')); ?>" class="btn btn-xs btn-dark"
                               style="float: right; color:white;"><i class="md md-view-module"></i> Add Leave Balance</a>
                        </div>
                    </div>
                </div>

                <br>
                <div class="tab-content">
                    <div class="tab-pane show active" id="basic-datatable-preview">
                        <div class="table-responsive">
                            <table id="datatable-buttons" class="table table-bordered dt-responsive nowrap w-100">
                                <thead>
                                    <tr>
                                        <th>Employee Name</th>
                                        <th>Total Days</th>
                                        <th>Remaining Days</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $leaveBalances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leaveBalance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($leaveBalance->employee->name); ?></td> <!-- Employee name -->
                                            <td><?php echo e($leaveBalance->total_day); ?></td>
                                            <td><?php echo e($leaveBalance->remaining_day); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="card-footer bg-secondary card_footer">
                    <div class="btn-group" role="group">
                        <a type="button" class="btn btn-xs btn-dark">Print</a>
                        <a type="button" class="btn btn-xs btn-warning">Excel</a>
                        <a type="button" class="btn btn-xs btn-dark">PDF</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('couston_CSS'); ?>
    <!-- DataTables -->
    <link href="<?php echo e(asset('backend/assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('backend/assets/libs/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css')); ?>"
          rel="stylesheet">
    <link href="<?php echo e(asset('backend/assets/libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css')); ?>"
          rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('couston_js'); ?>
    <!-- Required datatable js -->
    <script src="<?php echo e(asset('backend/assets/libs/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/assets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/assets/libs/datatables.net-buttons/js/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/assets/libs/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/assets/libs/datatables.net-responsive/js/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/assets/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shorifuddin/Downloads/Laravel-CRUD-main/resources/views/backend/leaveBalance/all.blade.php ENDPATH**/ ?>
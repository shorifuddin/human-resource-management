<?php $__env->startSection('content'); ?>
    <?php if(Session::has('success')): ?>
        <script>
            swal({
                title: "Good job!",
                text: "<?php echo e(Session::get('success')); ?>",
                icon: "success",
                timer: 3000,
            });
        </script>
    <?php endif; ?>

    <?php if(Session::has('error')): ?>
        <script>
            swal({
                title: "Error!",
                text: "<?php echo e(Session::get('error')); ?>",
                icon: "error",
            });
        </script>
    <?php endif; ?>

    <br>
    <div class="row container">
        <div class="col-md-12 container">
            <div class="card">
                <div class="card-header bg-secondary card_header">
                    <div class="row">
                        <div class="col-md-8 card_header_title">
                            <i class="md md-add-circle"></i> Attendance for <?php echo e($today->toFormattedDateString()); ?>

                        </div>
                        <div class="col-md-4 card_header_btn ">
                            
                        </div>
                    </div>
                </div>
                <br>
                <div class="tab-content">
                    <div class="tab-pane show active" id="basic-datatable-preview">
                        
                            <div class="row">
                                <div class="col-sm-12">
                                    <table class="table table-bordered dt-responsive nowrap w-100">
                                        <thead>
                                            <tr>
                                                <th>Employee Name</th>
                                                <th>Check In Time</th>
                                                <th>Check Out Time</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $attendanceStatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($status['employee']->name); ?></td>
                                                    <td><?php echo e($status['check_in_time'] ? \Carbon\Carbon::parse($status['check_in_time'])->format('h:i A') : 'Not Checked In'); ?></td>
                                                    <td><?php echo e($status['check_out_time'] ? \Carbon\Carbon::parse($status['check_out_time'])->format('h:i A') : 'Not Checked Out'); ?></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-footer bg-secondary card_footer">
                    <div class="btn-group" role="group">
                        <a type="button" class="btn btn-xs btn-dark">Print</a>
                        <a type="button" class="btn btn-xs btn-warning">Excel</a>
                        <a type="button" class="btn btn-xs btn-dark">PDF</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('couston_CSS'); ?>
    <!-- DataTables -->
    <link href="<?php echo e(asset('backend')); ?>/assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('backend')); ?>/assets/libs/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css" rel="stylesheet" type="text/css" />
    <!-- Responsive datatable examples -->
    <link href="<?php echo e(asset('backend')); ?>/assets/libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('couston_js'); ?>
    <!-- Required datatable js -->
    <script src="<?php echo e(asset('backend')); ?>/assets/libs/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/assets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
    <!-- Buttons examples -->
    <script src="<?php echo e(asset('backend')); ?>/assets/libs/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/assets/libs/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/assets/libs/jszip/jszip.min.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/assets/libs/pdfmake/build/pdfmake.min.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/assets/libs/pdfmake/build/vfs_fonts.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/assets/libs/datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/assets/libs/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/assets/libs/datatables.net-buttons/js/buttons.colVis.min.js"></script>

    <!-- Responsive examples -->
    <script src="<?php echo e(asset('backend')); ?>/assets/libs/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/assets/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js"></script>

    <!-- Datatable init js -->
    <script src="<?php echo e(asset('backend')); ?>/assets/js/pages/datatables.init.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shorifuddin/Downloads/Laravel-CRUD-main/resources/views/backend/attendance/all.blade.php ENDPATH**/ ?>
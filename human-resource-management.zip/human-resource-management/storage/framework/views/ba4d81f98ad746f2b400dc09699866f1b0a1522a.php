<?php $__env->startSection('content'); ?>
    <?php if(Session::has('success')): ?>
        <script>
            swal({
                title: "Good job!",
                text: "The operation completed successfully!",
                icon: "success",
                timer: 3000,
            });
        </script>
    <?php endif; ?>

    <?php if(Session::has('error')): ?>
        <script>
            swal({
                title: "Error!",
                text: "Something went wrong!",
                icon: "error",
            });
        </script>
    <?php endif; ?>

    <br>
    <div class="row container">
        <div class="col-md-12 container">
            <div class="card">
                <div class="card-header bg-secondary card_header">
                    <div class="row">
                        <div class="col-md-8 card_header_title">
                            <i class="md md-add-circle "></i> All Employee Information
                        </div>
                        <div class="col-md-4 card_header_btn">
                            <a href="<?php echo e(route('employee.create')); ?>" class="btn btn-xs btn-dark" style="float: right; color:white;">
                                <i class="md md-view-module"></i> Add Employee
                            </a>
                        </div>
                    </div>
                </div>
                <br>
                <div class="tab-content">
                    <div class="tab-pane show active" id="basic-datatable-preview">
                        <div id="basic-datatable_wrapper" class="dataTables_wrapper dt-bootstrap5 no-footer">
                            <div class="row">
                                <div class="col-sm-12">
                                    <table class="table table-bordered dt-responsive nowrap w-100">
                                        <thead>
                                            <tr>
                                                <th>Name</th>
                                                <th>Phone</th>
                                                <th>Email</th>
                                                <th>Username</th>
                                                <th>Photo</th>
                                                <th>Manage</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($employee->name); ?></td>
                                                    <td><?php echo e($employee->phone); ?></td>
                                                    <td><?php echo e($employee->email); ?></td>
                                                    <td><?php echo e($employee->username); ?></td>
                                                    <td>
                                                        <?php if(!empty($employee->image)): ?>
                                                            <img class="img-fluid img" src="<?php echo e(asset('upload/employee/' . $employee->image)); ?>" style="width: 50px;">
                                                        <?php else: ?>
                                                            <img class="img-fluid img" src="<?php echo e(asset('upload/avater.jpg')); ?>" style="width: 50px;">
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <div class="btn-group mb-2">
                                                            <div class="btn-group">
                                                                <button type="button" class="btn btn-dark dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                                                                    Manage <span class="caret"></span>
                                                                </button>
                                                                <div class="dropdown-menu">
                                                                    <a class="dropdown-item" href="<?php echo e(route('employee.edit', $employee->id)); ?>">Edit</a>
                                                                    <a class="dropdown-item" href="<?php echo e(route('employee.show', $employee->id)); ?>">View</a>
                                                                    <a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#delete-modal-<?php echo e($employee->id); ?>">Delete</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>

                                                <!-- Delete Modal -->
                                                <div id="delete-modal-<?php echo e($employee->id); ?>" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="delete-modalLabel-<?php echo e($employee->id); ?>" aria-hidden="true">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <div class="modal-header modal-colored-header bg-danger">
                                                                <h4 class="modal-title" id="delete-modalLabel">Warning</h4>
                                                            </div>
                                                            <div class="modal-body">
                                                                <p>Are you sure you want to delete <b><?php echo e($employee->name); ?></b>?</p>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-light" data-bs-dismiss="modal">No</button>
                                                                <form id="delete-form"
                                                                    action="<?php echo e(route('employee.destroy', $employee->id)); ?>"
                                                                    method="POST" style="display: none;">
                                                                    <?php echo csrf_field(); ?>
                                                                    <?php echo method_field('DELETE'); ?>
                                                                    <button type="submit" class="btn btn-dark">Yes</button>
                                                                </form>
                                                                
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- End Modal -->
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card-footer bg-secondary card_footer">
                    <div class="btn-group" role="group">
                        <a type="button" class="btn btn-xs btn-dark">Print</a>
                        <a type="button" class="btn btn-xs btn-warning">Excel</a>
                        <a type="button" class="btn btn-xs btn-dark">PDF</a>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_css'); ?>
    <!-- DataTables -->
    <link href="<?php echo e(asset('backend')); ?>/assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('backend')); ?>/assets/libs/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css" rel="stylesheet" type="text/css" />
    <!-- Responsive datatable examples -->
    <link href="<?php echo e(asset('backend')); ?>/assets/libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_js'); ?>
    <!-- Required datatable js -->
    <script src="<?php echo e(asset('backend')); ?>/assets/libs/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/assets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
    <!-- Buttons examples -->
    <script src="<?php echo e(asset('backend')); ?>/assets/libs/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/assets/libs/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/assets/libs/jszip/jszip.min.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/assets/libs/pdfmake/build/pdfmake.min.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/assets/libs/pdfmake/build/vfs_fonts.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/assets/libs/datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/assets/libs/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/assets/libs/datatables.net-buttons/js/buttons.colVis.min.js"></script>

    <!-- Responsive examples -->
    <script src="<?php echo e(asset('backend')); ?>/assets/libs/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/assets/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js"></script>

    <!-- Datatable init js -->
    <script src="<?php echo e(asset('backend')); ?>/assets/js/pages/datatables.init.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/shorifuddin/Downloads/Human/resources/views/backend/employee/all.blade.php ENDPATH**/ ?>